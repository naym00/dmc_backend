from django.apps import AppConfig


class LastlogConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'lastlog'
